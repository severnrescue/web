﻿You can do whatever you want with these icons (use on web or in desktop applications) as long as you don’t pass them off as your own and remove this readme file. A credit statement and a link back to
http://led24.de/iconset/ or http://led24.de/ would be appreciated.

Follow us on twitter http://twitter.com/gasyoun or email leds24@gmail.com
512 icons 20/05/2009