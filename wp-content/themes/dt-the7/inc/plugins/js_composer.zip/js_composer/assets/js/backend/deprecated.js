(function ( $ ) {
	if ( _.isUndefined( window.vc ) ) {
		window.vc = {};
	}
	// removed all deprecated up to 4.7
})( window.jQuery );